//Write a program to print your name in Dart
void main() {
  print("Mohsin Shah");
}
