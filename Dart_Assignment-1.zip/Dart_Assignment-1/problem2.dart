//Problem2 print with single and double quotes
void main() {
  print('"Hello I am "John Doe"');
  print("Hello I'am \"John Doe\"");
}
