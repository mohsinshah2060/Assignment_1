//problem9-remove all whitespace

void main() {
  String name = "Mohsin Shah";
  String str = name.replaceAll(" ", "");
  print(str);
}
