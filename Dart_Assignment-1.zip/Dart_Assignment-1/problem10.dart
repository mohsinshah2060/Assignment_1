//problem10-String to integer (type cast)
void main() {
  String name = "123";
  int number = int.parse(name);

  print("String $name to Integer $number");
}
