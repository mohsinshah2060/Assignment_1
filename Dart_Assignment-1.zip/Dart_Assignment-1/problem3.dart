//problem3 Declar constant type of value
void main() {
  const number = 7;
  //number = number + 3;
  //not modifiy after declearing constant
  print("This is a constant number $number");
}
