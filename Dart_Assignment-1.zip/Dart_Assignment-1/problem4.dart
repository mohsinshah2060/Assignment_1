//Problem4-
void main() {
  var p = 5000;
  var t = 3;
  var r = 10;
  var interest = (p * t * r) / 100;
  print("Interest =$interest");
}
