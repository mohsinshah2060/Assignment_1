//problem-7 Swaping two integer number

void main() {
  int num1 = 10;
  int num2 = 20;

  print("before swaping number 1 =$num1");
  print("before swaping number 2 =$num2");

  int temp = num1;
  num1 = num2;
  num2 = temp;

  print("after swaping number 1 =$num1");
  print("after swaping number 2 =$num2");
}
