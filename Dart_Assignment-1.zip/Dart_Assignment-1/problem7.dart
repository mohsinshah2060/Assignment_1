//problem7- quotient and reminder two interger number

void main() {
  int num1 = 10;
  int num2 = 3;

  print("The quotient ${num1 ~/ num2}");
  print("The reminder ${num1 % num2}");
}
